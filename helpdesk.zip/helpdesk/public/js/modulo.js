const BASEURL = `${window.location.origin}/helpdesk`;
export {
    BASEURL,
};

